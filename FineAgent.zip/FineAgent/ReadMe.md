#### 操作步骤如下: 

- 移除之前使用的激活方式（不管是Z大的还是Rover大佬的补丁）；

- 在`idea.vmoptions`文件中引入补丁（只能有一个`-javaagent`配置项）；

- 重启Jetbrains产品（为了让agent生效，必须重启）；

- 填入激活码，只能用[本站](https://www.jiweichengzhu.com/idea/code)提供的，不能用其他的激活码；

- 本补丁不支持直接拖拽进行安装，必须使用手动引入agent的方式；
